import{b as a,c as b}from"./chunk-JWIEPCRG.js";import"./chunk-2K7NMRC4.js";export{a as GESTURE_CONTROLLER,b as createGesture};
