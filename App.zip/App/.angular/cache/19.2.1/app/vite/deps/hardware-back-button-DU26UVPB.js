import {
  MENU_BACK_BUTTON_PRIORITY,
  OVERLAY_BACK_BUTTON_PRIORITY,
  blockHardwareBackButton,
  shouldUseCloseWatcher,
  startHardwareBackButton
} from "./chunk-R5ME7X4G.js";
import "./chunk-XPJ5GYR7.js";
import "./chunk-YBKELWOD.js";
import "./chunk-ACUVEYEP.js";
import "./chunk-SGG6ZD6O.js";
export {
  MENU_BACK_BUTTON_PRIORITY,
  OVERLAY_BACK_BUTTON_PRIORITY,
  blockHardwareBackButton,
  shouldUseCloseWatcher,
  startHardwareBackButton
};
