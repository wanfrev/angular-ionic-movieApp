export const environment = {
  production: false,
  apiUrl: 'http://localhost:5000/api', // URL fija para desarrollo
};
