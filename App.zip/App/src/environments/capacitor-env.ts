
export const CAPACITOR_SERVER_URL = 'http://192.168.75.1:5000';
