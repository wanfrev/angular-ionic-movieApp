export const environment = {
  production: true,
  apiUrl: 'angular-ionic-movie-app.vercel.app',
};
