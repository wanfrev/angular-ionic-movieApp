import { NgModule } from '@angular/core';
import { IonicModule } from '@ionic/angular';

@NgModule({
  imports: [IonicModule.forRoot()],
  exports: [IonicModule]
})
export class IonicFeatureModule {}
