module.exports = {
  apiUrl: 'https://api.themoviedb.org/3',
  apiKey: '64d148b6a9644b7ea9ae5b72c887014a', // Reemplaza con tu clave de API
};