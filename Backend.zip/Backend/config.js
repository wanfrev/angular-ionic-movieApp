module.exports = {
  apiUrl: 'https://api.themoviedb.org/3',
  apiKey: process.env.TMDB_API_KEY,
};